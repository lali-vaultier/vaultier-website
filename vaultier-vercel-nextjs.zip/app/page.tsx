"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

const abbreviationPaths = [
  "M129.4,208.8c3.2,7,6.2,9.2,7,9.6h-9.9c-1.2,0-2.3-.8-2.8-1.9l-44.4-119.6c-4.7-11.9-9.1-14.4-10.1-15h13.5c.8,0,1.4.7,1.2,1.4-.4,2,.2,5.9,2.7,12.4l40.6,108.2.6,1.5,40.7-110.3c2.2-6,2.1-9.5,1.3-11.4-.4-.8.2-1.8,1.1-1.8h9.2c-.6.4-5.2,2.5-9.7,15l-41.2,111c-.1.3,0,.7,0,1Z",
  "M342.4,218.6c4.8-1.5,5.9-3.7,5.9-8.7v-117.1c0-3.8-.9-9-7.4-11.2h2.2c4.7,0,7.1,0,8.7,0,6.2,0,22.5,0,30.2,0,32.9,0,43.5,16.8,43.8,32.8.3,18-12.3,35.8-42.8,36.3l46.2,59.8c3.4,3.9,6.8,7.3,11.2,8.1h-22.1c4-2.3,3.2-6-1.2-11.5l-43.3-56.4c-5.7-.2-17.9-.1-17.9-.1v59.1c0,5,1.1,7,6.2,9,.1,0-19.7,0-19.7,0ZM384,83.8h-24.4c-2,.2-3.6,3-3.6,5v59.1c8.7,0,21.9,0,27.7,0,28.7,0,36.2-17.5,36.2-32s-7.1-32-35.8-32Z",
  "M332.3,82.3c.5,2.9,1.5,6.7,3,13.1.7,2.9-1.4,1-2.3,0-5.7-7-15.7-11.6-26.4-11.6h-15.1c-.7,0-1.3.6-1.3,1.3v119.6c0,6.5,4.1,10.7,6.3,13.7h-20.5c2.5-3,6.1-7.3,6.1-13.8v-119c0-1.4-.7-1.8-2.3-1.8h-13.6c-10.9,0-20.5,4.4-26.1,11.6-1.7,2.2-3.3,2.7-2.8,0,1.2-5.7,2.4-11.6,2.6-13,0-.2.2-.3.4-.3h91.5c.2,0,.4.1.4.3Z",
  "M200.4,198.7c0,11.8,1.2,15.1,2.1,16.5.3.5.9,1.3,1.5,1.3h44c9.7,0,13.5-3.2,20.3-10.2h0c-2.3,5.8-3,7.1-5.1,9.1-2.3,2.3-6.1,3.1-8.9,3.1h-65.7s4.1-3.3,4.1-18.8v-99.5c0-14.5-.2-17.8-4.1-18.8h15.5c-3.2,1.1-3.7,3.1-3.7,18.8v98.4Z",
];

const mobileLetterLayout = [
  { id: "V", pathIndex: 0, transform: "translate(-49.6 -17)" },
  { id: "L", pathIndex: 3, transform: "translate(-153.4 127)" },
  { id: "T", pathIndex: 2, transform: "translate(-211.4 272)" },
  { id: "R", pathIndex: 1, transform: "translate(-315.5 417)" },
];

function VltrPathSet({
  prefix,
  fill,
  vectorEffect,
}: {
  prefix: string;
  fill?: string;
  vectorEffect?: string;
}) {
  return (
    <>
      <g className="vltr-desktop-layout">
        {abbreviationPaths.map((path, index) => (
          <path key={`${prefix}-desktop-${index}`} d={path} fill={fill} vectorEffect={vectorEffect} />
        ))}
      </g>
      <g className="vltr-mobile-layout">
        {mobileLetterLayout.map(({ id, pathIndex, transform }) => (
          <path
            key={`${prefix}-mobile-${id}`}
            d={abbreviationPaths[pathIndex]}
            transform={transform}
            fill={fill}
            vectorEffect={vectorEffect}
          />
        ))}
      </g>
    </>
  );
}

export default function Home() {
  const experience = useRef<HTMLDivElement>(null);
  const stage = useRef<HTMLElement>(null);
  const cutoutViewport = useRef<SVGSVGElement>(null);
  const cutoutShape = useRef<SVGGElement>(null);
  const cutoutDepthViewport = useRef<SVGSVGElement>(null);
  const cutoutDepthShape = useRef<SVGGElement>(null);
  const openingCopy = useRef<HTMLDivElement>(null);
  const finalPaper = useRef<HTMLDivElement>(null);
  const invitationCopy = useRef<HTMLDivElement>(null);
  const [invitationVisible, setInvitationVisible] = useState(false);

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const syncCutoutViewport = () => {
      const mobile = window.innerWidth <= 680;
      const viewBox = mobile ? "0 0 150 700" : "0 0 500 287.5";
      cutoutViewport.current?.setAttribute("x", mobile ? "0" : "23%");
      cutoutViewport.current?.setAttribute("width", mobile ? "100%" : "54%");
      cutoutViewport.current?.setAttribute("viewBox", viewBox);
      cutoutDepthViewport.current?.setAttribute("x", mobile ? "0" : "23%");
      cutoutDepthViewport.current?.setAttribute("width", mobile ? "100%" : "54%");
      cutoutDepthViewport.current?.setAttribute("viewBox", viewBox);
    };

    syncCutoutViewport();
    window.addEventListener("resize", syncCutoutViewport);

    if (reduceMotion) {
      const frame = window.requestAnimationFrame(() => setInvitationVisible(true));
      return () => {
        window.cancelAnimationFrame(frame);
        window.removeEventListener("resize", syncCutoutViewport);
      };
    }

    const context = gsap.context(() => {
      const timeline = gsap.timeline({
        defaults: { ease: "none" },
        scrollTrigger: {
          trigger: experience.current,
          start: "top top",
          end: "bottom bottom",
          scrub: 0.7,
          invalidateOnRefresh: true,
          onUpdate: (self) => setInvitationVisible(self.progress > 0.88),
        },
      });

      timeline
        .fromTo([cutoutShape.current, cutoutDepthShape.current],
          { scale: 1 },
          { scale: 2.5, transformOrigin: "50% 50%", duration: 0.56 },
          0,
        )
        .to(cutoutDepthShape.current, { autoAlpha: 0, duration: 0.04 }, 0.54)
        .to(cutoutShape.current,
          { attr: { "stroke-width": 700 }, duration: 0.12 },
          0.56,
        )
        .fromTo(openingCopy.current,
          { opacity: 0, y: 12 },
          { opacity: 1, y: 0, duration: 0.12 },
          0.62,
        )
        .to(openingCopy.current, { opacity: 0, y: -8, duration: 0.1 }, 0.82)
        .fromTo(finalPaper.current,
          { autoAlpha: 0 },
          { autoAlpha: 1, duration: 0.12 },
          0.88,
        )
        .fromTo(invitationCopy.current,
          { opacity: 0, y: 10 },
          { opacity: 1, y: 0, duration: 0.1 },
          0.9,
        );
    }, experience);

    return () => {
      window.removeEventListener("resize", syncCutoutViewport);
      context.revert();
    };
  }, []);

  return (
    <main ref={experience} className="experience">
      <section ref={stage} className="invitation-stage" aria-label="Vaultier private invitation">
        <div className="textile" aria-hidden="true" />

        <div className="stationery-card" aria-label="Vaultier">
          <svg className="paper-layer" width="100%" height="100%" aria-hidden="true">
            <defs>
              <mask
                id="vltr-paper-cutout"
                x="0"
                y="0"
                width="100%"
                height="100%"
                maskUnits="userSpaceOnUse"
                maskContentUnits="userSpaceOnUse"
                style={{ maskType: "luminance" }}
              >
                <rect width="100%" height="100%" fill="#fff" />
                <svg
                  ref={cutoutViewport}
                  className="cutout-mask-vector"
                  x="23%"
                  y="0"
                  width="54%"
                  height="100%"
                  viewBox="0 0 500 287.5"
                  preserveAspectRatio="xMidYMid meet"
                  overflow="visible"
                >
                  <g
                    ref={cutoutShape}
                    className="cutout-mask-shape"
                    fill="#000"
                    stroke="#000"
                    strokeWidth="0"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <VltrPathSet prefix="mask" />
                  </g>
                </svg>
              </mask>
            </defs>
            <g mask="url(#vltr-paper-cutout)">
              <rect width="100%" height="100%" fill="#EFE9DF" />
              <image
                href="/images/vaultier-buttercream-fine-cardstock.jpg"
                width="100%"
                height="100%"
                preserveAspectRatio="xMidYMid slice"
                style={{ mixBlendMode: "luminosity" }}
              />
              <rect width="100%" height="100%" fill="#EFE9DF" opacity=".38" />
              <rect className="paper-frame-shadow" x="5%" y="6%" width="90%" height="88%" />
              <rect className="paper-frame-highlight" x="5.15%" y="6.15%" width="89.7%" height="87.7%" />
            </g>
          </svg>
          <svg className="cutout-depth-layer" width="100%" height="100%" aria-hidden="true">
            <defs>
              <filter
                id="vltr-cut-shadow"
                x="-20%"
                y="-20%"
                width="140%"
                height="140%"
                colorInterpolationFilters="sRGB"
              >
                <feGaussianBlur stdDeviation="0.24" result="soft-shadow" />
                <feOffset in="soft-shadow" dx="0.48" dy="0.58" />
              </filter>
              <linearGradient
                id="vltr-paper-wall-tone"
                x1="0"
                y1="0"
                x2="1"
                y2="1"
              >
                <stop offset="0" stopColor="#f5eee4" />
                <stop offset="0.48" stopColor="#e8dfd3" />
                <stop offset="1" stopColor="#d4c7b8" />
              </linearGradient>
            </defs>
            <svg
              ref={cutoutDepthViewport}
              className="cutout-depth-vector"
              x="23%"
              y="0"
              width="54%"
              height="100%"
              viewBox="0 0 500 287.5"
              preserveAspectRatio="xMidYMid meet"
              overflow="visible"
            >
              <g ref={cutoutDepthShape} className="cutout-depth-shape" fill="none">
                <defs>
                  <clipPath id="vltr-aperture-clip" clipPathUnits="userSpaceOnUse">
                    <VltrPathSet prefix="clip" fill="#fff" />
                  </clipPath>
                </defs>
                <g clipPath="url(#vltr-aperture-clip)">
                  <g className="cutout-cast-shadow" filter="url(#vltr-cut-shadow)">
                    <VltrPathSet prefix="shadow" vectorEffect="non-scaling-stroke" />
                  </g>
                  <g className="cutout-paper-wall">
                    <VltrPathSet prefix="wall" vectorEffect="non-scaling-stroke" />
                  </g>
                </g>
              </g>
            </svg>
          </svg>
        </div>

        <div ref={openingCopy} className="editorial-copy opening-copy" aria-hidden="true">
          <p className="eyebrow">Private collection stewardship</p>
          <h1>An extraordinary collection<br />deserves extraordinary care.</h1>
          <p className="body-copy">
            Vaultier creates and maintains a lasting record of every piece, coordinating the documentation,
            protection and specialist care your collection requires.
          </p>
        </div>

        <div
          ref={finalPaper}
          className={`final-paper${invitationVisible ? " is-active" : ""}`}
          aria-hidden={!invitationVisible}
        >
          <svg className="final-paper-frame" width="100%" height="100%" aria-hidden="true">
            <rect className="paper-frame-shadow" x="5%" y="6%" width="90%" height="88%" />
            <rect className="paper-frame-highlight" x="5.15%" y="6.15%" width="89.7%" height="87.7%" />
          </svg>
          <svg className="letterpress-definitions" aria-hidden="true" focusable="false">
            <defs>
              <filter
                id="letterpress-display"
                x="-5%"
                y="-8%"
                width="110%"
                height="116%"
                colorInterpolationFilters="sRGB"
              >
                <feMorphology in="SourceAlpha" operator="dilate" radius="0.52" result="display-pressure" />
                <feComposite in="display-pressure" in2="SourceAlpha" operator="out" result="display-rim" />
                <feOffset in="display-rim" dx="-0.42" dy="-0.48" result="display-dark-rim" />
                <feFlood floodColor="#42331f" floodOpacity="0.18" result="display-dark-ink" />
                <feComposite in="display-dark-ink" in2="display-dark-rim" operator="in" result="display-shadow" />
                <feOffset in="display-rim" dx="0.42" dy="0.48" result="display-light-rim" />
                <feFlood floodColor="#fffaf1" floodOpacity="0.48" result="display-light-ink" />
                <feComposite in="display-light-ink" in2="display-light-rim" operator="in" result="display-highlight" />
                <feMerge>
                  <feMergeNode in="display-shadow" />
                  <feMergeNode in="SourceGraphic" />
                  <feMergeNode in="display-highlight" />
                </feMerge>
              </filter>
              <filter
                id="letterpress-fine"
                x="-6%"
                y="-14%"
                width="112%"
                height="128%"
                colorInterpolationFilters="sRGB"
              >
                <feMorphology in="SourceAlpha" operator="dilate" radius="0.34" result="fine-pressure" />
                <feComposite in="fine-pressure" in2="SourceAlpha" operator="out" result="fine-rim" />
                <feOffset in="fine-rim" dx="-0.28" dy="-0.32" result="fine-dark-rim" />
                <feFlood floodColor="#42331f" floodOpacity="0.2" result="fine-dark-ink" />
                <feComposite in="fine-dark-ink" in2="fine-dark-rim" operator="in" result="fine-shadow" />
                <feOffset in="fine-rim" dx="0.28" dy="0.32" result="fine-light-rim" />
                <feFlood floodColor="#fffaf1" floodOpacity="0.52" result="fine-light-ink" />
                <feComposite in="fine-light-ink" in2="fine-light-rim" operator="in" result="fine-highlight" />
                <feMerge>
                  <feMergeNode in="fine-shadow" />
                  <feMergeNode in="SourceGraphic" />
                  <feMergeNode in="fine-highlight" />
                </feMerge>
              </filter>
            </defs>
          </svg>
          <div ref={invitationCopy} className="editorial-copy invitation-copy">
            <h2>A more considered<br />way to own.</h2>
            <p className="body-copy">
              From insurance and valuations to ongoing care and preservation, Vaultier manages the details so you
              can simply enjoy what you own.
            </p>
            <Link
              href="/request-invitation"
              className="invitation-link"
              tabIndex={invitationVisible ? 0 : -1}
            >
              <span>Request a Private Invitation</span>
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
