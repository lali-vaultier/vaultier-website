# Vaultier Private Invitation

A standalone interactive invitation for Vaultier, built with Next.js, TypeScript, Tailwind CSS and GSAP ScrollTrigger.

## Requirements

- Node.js 20.9 or newer
- npm 10 or newer

## Local development

```bash
cp .env.example .env.local
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

Production verification:

```bash
npm run lint
npm run build
npm run start
```

## Environment variables

Copy `.env.example` to `.env.local` for local work. Add the same variables in Vercel under **Project Settings → Environment Variables**.

| Variable | Required | Purpose |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | Recommended | Canonical production URL used for Open Graph and X preview metadata. |
| `INVITATION_FORM_WEBHOOK_URL` | Optional | Server-side webhook destination for invitation applications. |
| `INVITATION_FORM_API_KEY` | Optional | Bearer token sent only from the server to the configured webhook. |

Without a webhook URL, the form remains in clearly labelled preview mode. It validates submissions but does not transmit or store data.

## Brand assets

The visible interface uses only the supplied Vaultier Abbreviation and Vaultier Logomark artwork. Both source SVGs are copied unchanged into `public/brand/` and rendered at their original proportions. Editor's Note Hairline Italic is bundled locally through `next/font/local`; Helvetica uses the visitor's licensed system installation with standard sans-serif fallbacks.

- `vaultier-abbreviation.svg` is the primary identifier on the closed invitation.
- `vaultier-logomark.svg` appears within the textile reveal and on the invitation application.
- The supplied `app/fonts/editors-note-hairline-italic.otf` is preloaded and self-hosted by Next.js.
- Put approved production photography in `public/images/` and use `next/image` for raster content shown in the interface.

The website palette is centralised in `app/globals.css`: Deep Teal Blue `#0F2A36`, Olive Green `#6B6F3A`, Wild Brown `#42331F`, Murky Grey `#ADA797`, Butter Cream `#EFE9DF`, Charcoal `#141412` and Off-white `#F6F4F2`. Material highlights and shadows are derived from these tokens with `color-mix()`.

Avoid committing unlicensed font files or original high-resolution brand masters that are not intended for web distribution.

## Deploying to Vercel

1. Push this directory to a GitHub, GitLab or Bitbucket repository.
2. In Vercel, choose **Add New → Project** and import the repository.
3. Vercel will detect Next.js automatically. Keep the default build command (`npm run build`) and output settings.
4. Add the environment variables described above.
5. Deploy, then set `NEXT_PUBLIC_SITE_URL` to the final production domain and redeploy so social metadata uses the canonical URL.
6. Add a custom domain under **Project Settings → Domains** if required.

The application does not use Showit embeds, Cloudflare Workers, ChatGPT Sites, or platform-specific runtime dependencies.

## Routes

- `/` — pinned, scroll-controlled invitation experience
- `/request-invitation` — responsive private invitation application
- `/api/request-invitation` — validated server-side form integration endpoint

## Accessibility and performance

- The reveal follows scroll position and reverses naturally.
- `prefers-reduced-motion` replaces the pinned animation with a readable linear presentation.
- The mask layer is isolated to reduce paint work, while GSAP cleans up its ScrollTrigger instance on unmount.
- Critical artwork is served locally; there are no third-party font or image requests.
